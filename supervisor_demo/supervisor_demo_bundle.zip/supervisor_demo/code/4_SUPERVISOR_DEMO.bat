@echo off
cd /d "%~dp0"
echo Opening the local Disclosure Verifier demo. Keep this window open.
echo No API key or extra Python packages are required.
python supervisor_demo.py
pause
