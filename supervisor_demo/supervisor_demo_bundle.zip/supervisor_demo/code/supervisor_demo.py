"""Local, standard-library-only supervisor demo on prepared pilot evidence."""
import argparse
from datetime import date
import html
from http.server import BaseHTTPRequestHandler, HTTPServer
import json
from pathlib import Path
from urllib.parse import parse_qs, urlencode, urlparse
import webbrowser

from common import load_dataset
from verifier import resolve_reference, run_rule

POLICIES = {
    'original_as_filed': 'Original report as filed',
    'corrected_named': 'Named corrected report',
    'as_known_packet': 'Active evidence at the cutoff',
    'unspecified': 'Version unspecified',
    'explicit_display_comparison': 'Displayed-value arithmetic',
}
NAMES = {'S': 'Supported', 'C': 'Contradicted', 'U': 'Underdetermined'}
SCENARIOS = [
    ('Original report', 'P013', 'original_as_filed', '2023-12-19'),
    ('Corrected report', 'P013', 'corrected_named', '2023-12-19'),
    ('Before withdrawal', 'P013', 'as_known_packet', '2023-10-18'),
    ('Withdrawal gap', 'P013', 'as_known_packet', '2023-10-25'),
    ('After replacement', 'P013', 'as_known_packet', '2023-12-19'),
    ('Rounding challenge', 'P018', 'corrected_named', '2023-12-19'),
]


def evaluate(case_id='P013', policy=None, cutoff=None):
    documents, facts, cases = load_dataset('pilot')
    matches = [c for c in cases if c['case_id'] == case_id]
    if not matches:
        raise ValueError('Choose one of the 30 pilot case IDs.')
    claim = dict(matches[0])
    if policy:
        if policy not in POLICIES:
            raise ValueError('Unknown authority policy.')
        if (policy == 'explicit_display_comparison') != (claim['policy'] == 'explicit_display_comparison'):
            raise ValueError('Arithmetic cases require their explicit two-document comparison policy.')
        claim['policy'] = policy
    if cutoff:
        claim['cutoff_date'] = date.fromisoformat(cutoff).isoformat()
    result = resolve_reference(claim, documents, facts)
    result['simple_control_label'] = run_rule('B4W', claim, documents, facts)
    # Exclude proposed labels from the demo response. They are not independent truth.
    public_claim = {k: v for k, v in claim.items() if k not in ('gold_label', 'label_source', 'template')}
    return public_claim, result, cases


def page(case_id='P013', policy=None, cutoff=None):
    claim, result, cases = evaluate(case_id, policy, cutoff)
    esc = lambda value: html.escape(str(value), quote=True)
    options = ''.join(f'<option value="{esc(c["case_id"])}" {"selected" if c["case_id"] == case_id else ""}>{esc(c["case_id"])} — {esc(c["issuer"])}</option>' for c in cases)
    choices = {'explicit_display_comparison': POLICIES['explicit_display_comparison']} if claim['policy'] == 'explicit_display_comparison' else {k:v for k,v in POLICIES.items() if k != 'explicit_display_comparison'}
    policies = ''.join(f'<option value="{k}" {"selected" if k == claim["policy"] else ""}>{v}</option>' for k,v in choices.items())
    links = ''.join(f'<a class="button" href="?{urlencode(dict(case=c, policy=p, cutoff=d))}">{esc(title)}</a>' for title,c,p,d in SCENARIOS)
    doc_rows = ''
    for d in result['documents']:
        status = 'Eligible' if d['eligible'] else 'Excluded: filed on/after cutoff'
        if d['withdrawn']:
            status += '; withdrawn for active-authority questions'
        url = d['url']
        if urlparse(url).scheme != 'https':
            raise ValueError('Evidence links must use HTTPS.')
        doc_rows += f'<tr><td><a href="{esc(url)}" target="_blank" rel="noopener noreferrer">{esc(d["doc_id"])}</a></td><td>{esc(d["filing_date"])}</td><td>{esc(status)}</td></tr>'
    fact_rows = ''.join(f'<tr><td>{esc(f["fact_id"])} / {esc(f["doc_id"])}</td><td>{esc(f["value"])}</td><td>{esc(f["unit"])}</td><td>{"Selected" if f["selected"] else "Not selected"}</td></tr>' for f in result['facts'])
    intervals = '; '.join('[' + ', '.join(pair) + ']' for pair in result['evidence_intervals']) or 'None'
    return f'''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<title>Disclosure Verifier — supervisor demo</title><style>
body{{font:16px/1.55 system-ui,sans-serif;background:#f3f6fa;color:#17253b;max-width:1050px;margin:36px auto;padding:0 20px}}
h1{{font-size:32px;margin-bottom:4px}} .sub{{color:#526176}} section{{background:white;border:1px solid #d9e2ed;border-radius:12px;padding:22px;margin:18px 0}}
label{{display:inline-block;margin:0 16px 12px 0}}select,input,button{{font:inherit;padding:8px;border:1px solid #a6b5c8;border-radius:5px;max-width:100%}}
button,.button{{background:#173f70;color:white;text-decoration:none;cursor:pointer}}.button{{display:inline-block;padding:7px 12px;margin:4px;border-radius:5px}}
table{{border-collapse:collapse;width:100%;font-size:14px}}td,th{{padding:10px;border-bottom:1px solid #d9e2ed;text-align:left}}th{{background:#eef3f9}}
.verdict{{font-size:26px;font-weight:700}}.S{{color:#176041}}.C{{color:#a12727}}.U{{color:#855600}}.note{{border-left:4px solid #b98520;padding-left:14px}} a{{color:#174f8d}}code{{overflow-wrap:anywhere}}
</style><h1>Disclosure Verifier</h1><p class="sub">Research prototype · 30 prepared pilot claims · no model API or training required</p>
<p class="note">This deterministic reference verifier operates on prepared facts and correction links. Their annotations remain provisional. It does not extract facts from raw filings or establish model accuracy.</p>
<section><h2>Guided SunPower demonstration</h2><p>The first five buttons keep the same claim and change only the policy or cutoff.</p>{links}</section>
<section><h2>Explore a case</h2><form method="get"><label>Claim<br><select name="case" onchange="location.href='?case='+encodeURIComponent(this.value)">{options}</select></label>
<label>Disclosure policy<br><select name="policy">{policies}</select></label><label>Cutoff date<br><input type="date" required name="cutoff" value="{esc(claim['cutoff_date'])}"></label><button>Verify</button></form>
<p><strong>{esc(claim['case_id'])}:</strong> {esc(claim['claim'])}</p><p>Period: {esc(claim['period_start'])} to {esc(claim['period_end'])}. Metric: {esc(claim['metric'])}.</p></section>
<section><div class="verdict {result['label']}">{result['label']} — {NAMES[result['label']]}</div><p>{esc(result['reason'])}</p>
<p>Simple withdrawal-aware control: <strong>{NAMES[result['simple_control_label']]}</strong>. Agreement here does not demonstrate superiority.</p>
<p>Claim interval: <code>{esc(result['claim_interval'])}</code>. Selected evidence intervals: <code>{esc(intervals)}</code>. Units follow the normalized facts below.</p></section>
<section><h2>Evidence trace</h2><p>Eligibility convention: official filing date must be strictly earlier than the cutoff. Same-day evidence is excluded conservatively; this is not a claim about exact dissemination time. Sources are limited to this packet.</p>
<table><tr><th>Source link</th><th>Filed</th><th>Status</th></tr>{doc_rows}</table><h3>Matching numerical facts</h3><table><tr><th>Fact / source</th><th>Value</th><th>Unit</th><th>Decision input</th></tr>{fact_rows}</table>
<p>Historical original-as-filed questions may use a withdrawn original to establish what that document reported. Active-authority questions cannot.</p></section>
<p class="sub">Pilot evidence is assistant-prepared and awaits independent review. Generated claims are research examples, not investment advice. Close the terminal or press Ctrl+C to stop the local demo.</p></html>'''


class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path != '/':
            self.send_error(404)
            return
        q = parse_qs(parsed.query)
        try:
            content = page(q.get('case', ['P013'])[0], q.get('policy', [None])[0], q.get('cutoff', [None])[0]).encode()
        except ValueError as exc:
            self.send_error(400, str(exc))
            return
        self.send_response(200)
        self.send_header('Content-Type', 'text/html; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(content)))
        self.end_headers()
        self.wfile.write(content)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--case', default='P013')
    parser.add_argument('--policy', choices=POLICIES)
    parser.add_argument('--cutoff')
    parser.add_argument('--json', action='store_true', help='Print one reference verdict and trace; do not start the browser')
    parser.add_argument('--export', type=Path, help='Write an HTML snapshot of this case; interactive controls require the local server')
    parser.add_argument('--port', type=int, default=8765)
    parser.add_argument('--no-browser', action='store_true')
    args = parser.parse_args()
    if args.json:
        claim, result, _ = evaluate(args.case, args.policy, args.cutoff)
        print(json.dumps({'claim': claim, 'result': result}, indent=2, default=str))
        return
    if args.export:
        args.export.write_text(page(args.case, args.policy, args.cutoff), encoding='utf-8')
        return
    url = f'http://127.0.0.1:{args.port}/?' + urlencode({k:v for k,v in dict(case=args.case,policy=args.policy,cutoff=args.cutoff).items() if v})
    with HTTPServer(('127.0.0.1', args.port), Handler) as server:
        print('Disclosure Verifier: '+url, flush=True)
        print('Prepared pilot evidence; draft annotations. Ctrl+C stops the demo.', flush=True)
        if not args.no_browser:
            webbrowser.open(url)
        try:
            server.serve_forever()
        except KeyboardInterrupt:
            pass


if __name__ == '__main__':
    main()
